<h1 align="center">
  <strong><a href="https://github.com/ArthurFiorette/polar/" target="_blank">Polar</a> 🏔</strong>
</h1>
<p align="center">
  <i>My personal <b>portfolio</b> and <b>blog</b>!</i>
</p>

## 📃 License

Licensed under the **GNU General Public License**. See [`LICENSE`](LICENSE) for more informations.

## 📧 Contact

See my contact information on my [GitHub Profile Page](https://github.com/ArthurFiorette) or open a new issue.
