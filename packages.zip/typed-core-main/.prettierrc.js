// https://github.com/ArthurFiorette/prettier-config

module.exports = require('@arthurfiorette/prettier-config')({
  tsdoc: true
});
