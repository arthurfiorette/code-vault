# Bootstrap galery

This is a repository created to learn and practice about **Bootstrap**, **Webpack**, **jQuery** and **Web Development** in general. Feel free to contribute with this project.

## Openning
With this repo on your local machine, run **npm start** and open the browser on localhost:1227.
  
## Building Notes
I'm still building this website.

## License
Licensed under the **GNU General Public License v3.0**. See `./LICENSE` for more informations.

## Contact
See my contact information on my [GitHub Profile Page](https://github.com/ArthurFiorette).
