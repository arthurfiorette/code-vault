// SASS
import './scss/index.scss';

// Dependencias
import 'jquery';
import 'bootstrap';

// JS
import './js/core/includes';
import './js/plugins/cityButtons';
