# Flappy Bird

This is a repository created to learn and pratice about **TypeScript**, **JavaScript**, **HTML** and **CSS**. Feel free with contribute to this project.

<a href="https://hazork.github.io/flappy">
  <img src=".github/images/page.png" alt="Game Preview">
</a>

## Deprecation Note ⚠️
As this project was a simple project to practice and learn, I do not pretend mains to continue to contribute according to my learning, since I have other priorities.

## Opening

The project is currently being stored on [Github Pages](https://hazork.github.io/flappy/). but you can also download the project and open `./index.html` in your local machine.

## License
Licensed under the **GNU General Public License v3.0**. See `./LICENSE` for more informations.

## Contact
See my contact information on my [GitHub Profile Page](https://github.com/ArthurFiorette).
