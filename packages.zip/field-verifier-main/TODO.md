### Some notes about any improvements that this project could have, ordered by priority:

- [ ] Find better names pls.