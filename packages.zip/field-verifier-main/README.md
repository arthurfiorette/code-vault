<p align="center">
  <a href="https://github.com/ArthurFiorette/field-verifier/network/members"><img
      src="https://img.shields.io/github/forks/ArthurFiorette/field-verifier?logo=github&style=flat-square&label=Forks"
      target="_blank"
      alt="Forks" /></a>
  <a href="https://github.com/ArthurFiorette/field-verifier/issues"><img
      src="https://img.shields.io/github/issues/ArthurFiorette/field-verifier?logo=github&style=flat-square&label=Issues"
      target="_blank"
      alt="Issues" /></a>
  <a href="https://github.com/ArthurFiorette/field-verifier/stargazers"><img
      src="https://img.shields.io/github/stars/ArthurFiorette/field-verifier?logo=github&style=flat-square&label=Stars"
      target="_blank"
      alt="Stars" /></a>
  <a href="https://github.com/ArthurFiorette/field-verifier/blob/main/LICENSE"><img
      src="https://img.shields.io/github/license/ArthurFiorette/field-verifier?logo=github&style=flat-square&label=License"
      target="_blank"
      alt="License" /></a>
  <a href="https://codecov.io/gh/arthurfiorette/field-verifier"><img
      src="https://codecov.io/gh/arthurfiorette/field-verifier/branch/main/graph/badge.svg"
      target="_blank"
      alt="Codecov" /></a>
  <a href="https://www.npmjs.com/package/field-verifier"><img
      src="https://img.shields.io/npm/v/field-verifier?color=CB3837&logo=npm&style=flat-square&label=Npm"
      target="_blank"
      alt="Npm" /></a>
</p>

<h1 align="center">
  <strong><a href="https://github.com/ArthurFiorette/field-verifier/" target="_blank">Field Verifier</a> ✅</strong>
</h1>
<p align="center">
  <i>An <b>Typed</b> object validator for Node.js</i>
</p>

## 📖 About

TODO

This package does not rely at dependency to work. Compatible to NodeJS and Browser code. The code is analyzed by ESLint and tested with Jest.

## ⬇️ Downloading

This module has few dependencies, so, this means that we are super light and quick to install, as you can see by downloading it with **Npm**:

```sh
$ npm i --save field-verifier
```

Or with **Yarn**:

```sh
$ npm i --save field-verifier
```

## 💻 Contributing

This is a small project, and I don't have any specific rules for contributions, you can modify anything and then make a pull-request and i'll analyze. Just be careful not to run away from the main idea of the package.

## 📚 Examples

```js
import { validate } from 'field-verifier';

const input = {
  name: {
    firstName: 'John',
    lastName: { first: 'Smith', second: '' }
  },
  age: 12
};

const errors = await validate(input, ({ parse, validate }) => {
  parse('age', x => x > 1, 'a person cannot have an age lower than 1 year');

  validate('name', ({ parse, validate }) => {
    parse('firstName', n => n.length > 3, 'at least 3 characters length');

    validate('lastName', ({ parse }) => {
      // Rejects every condition
      parse('first', () => false, 'you got rejected :P');

      // Ignores the second name
    });
  });
});

// outputs: [ { field: 'name.firstName', message: 'at least 3 characters length' } ]
console.log(errors);
```

## 📃 License

Licensed under the **MIT**. See [`LICENSE`](LICENSE) for more informations.

## 📧 Contact

See my contact information on my [GitHub Profile Page](https://github.com/ArthurFiorette) or open a new issue.
