### Some notes about any improvements that this project could have, ordered by priority:

- [ ] Code documentation.
- [ ] Create the project wiki.
- [ ] Add a id for each registered listener, so you don't have to keep the function as a variable
- [ ] Cover all code
