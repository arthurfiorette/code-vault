[![Forks][forks-shield]][forks-url][![Stargazers][stars-shield]][stars-url][![Issues][issues-shield]][issues-url][![License][license-shield]][license-url]

# Adventure Pass 

A battle pass minecraft plugin focused on vanilla tasks!

## ⚠️ Deprecation Notes ⚠️

This project used to be my first contact with java and minecraft coding. As all in the life, my priorities changed and i do not work more on this project.

[forks-shield]: https://img.shields.io/github/forks/Hazork/AdventurePass?style=flat-square
[forks-url]: https://github.com/Hazork/AdventurePass/network/members

[stars-shield]: https://img.shields.io/github/stars/Hazork/AdventurePass?style=flat-square
[stars-url]: https://github.com/Hazork/AdventurePass/stargazers

[issues-shield]: https://img.shields.io/github/issues/Hazork/AdventurePass?style=flat-square
[issues-url]: https://github.com/Hazork/AdventurePass/issues

[license-shield]: https://img.shields.io/github/license/Hazork/AdventurePass?style=flat-square
[license-url]: https://github.com/Hazork/AdventurePass/blob/main/LICENSE
