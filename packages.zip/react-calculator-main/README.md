# React Calculator
This is a repository created to learn and practice about **React** and **Web Development** in general. Feel free to contribute with this project.

## Deprecation Note ⚠️
As this project was a simple project to practice and learn, I do not pretend mains to continue to contribute according to my learning, since I have other priorities.

## Openning
You can open it [here](https://arthurfiorette.github.io/react-calculator/) with the github pages or build it yourself downloading this repo and using `npm run build`.

## License
Licensed under the **GNU General Public License v3.0**. See `./LICENSE` for more informations.

## Contact
See my contact information on my [GitHub Profile Page](https://github.com/ArthurFiorette).
