# Email sender

This is a repository created to learn and practice about **Containerization** and **Software Architecture**. Feel free to contribute with this project.

## Deprecation Note ⚠️
As this project was a simple project to practice and learn, I do not pretend mains to continue to contribute according to my learning, since I have other priorities.

## Openning

The email sender is a docker project. As i said and so, you can run it with:

```
docker-compose up
```

If you wanna, you can scale the workers containers with the --scale. (default = 3)

```
docker-compose up --scale worker=1
```

## Notes
I'm converting all python files to js because the course instructor used python but i'm not familiarized with it at all, so, to my training i'll recode in js after completing it

## License
Licensed under the **GNU General Public License v3.0**. See `./LICENSE` for more informations.

## Contact
See my contact information on my [GitHub Profile Page](https://github.com/ArthurFiorette).
